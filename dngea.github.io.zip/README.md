# RoBOT.gitbub.io

DNGEA PORTFOLIO.

This is a project I started in 2019 when I first discovered about what coding was and 
its potential to provide an online space to show a personal portfolio.

At the beggining, the idea was to create a gallery for my pictures, however, it evolved and now the website
embraces a variety of different projects carried on during my years in Porto studying for 
a Masters' in Multimedia.


https://dngea.github.io/
